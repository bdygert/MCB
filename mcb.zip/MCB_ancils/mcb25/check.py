import numpy as np
import xarray as xr

mcb=xr.open_dataset('SIEMCB25TG.anc.nc')
ems = mcb.mean("time")['m01s00i301']
print(np.unique(ems))
